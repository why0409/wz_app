package com.szah.uccp.client.demo.config;

import com.iflytek.sc.ssp.uc.client.filter.FilterChainProxy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @description uccp配置文件
 * @author jlye
 * @date 2024/1/26
 */
@Slf4j
@Configuration
public class UccpClientConfig {

    /**
     * uc-client.properties
     * 配置文件路径，不配置默认从项目的resources取
     * @Description
     * @Author jiemin2
     * @Date 9:35 2021/4/15
     * @Param
     * @return
     **/
    @Value("${uccp.ucClient.config.url:}")
    private String configUrl;

    @Bean
    public FilterRegistrationBean ucClientFilterRegistration() {
        //如果未配置路径，则取这里的相对路径
        if(StringUtils.isBlank(configUrl)) {
            configUrl = this.getClass().getClassLoader().getResource("application.properties").getPath();
        }
        log.info("统一认证对接配置文件路径-ucClientConfigUrl={}", configUrl);
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new FilterChainProxy());
        registration.addUrlPatterns("/*");
        registration.addInitParameter("uc-config", configUrl);
        registration.addInitParameter("timeOut", "30");
        registration.setName("ucClientFilter");
        registration.setOrder(1);
        return registration;
    }

}

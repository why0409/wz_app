package com.szah.uccp.client.demo.controller;

import com.alibaba.fastjson.JSONObject;
import com.iflytek.sc.ssp.uc.client.constant.UCConstant;
import com.iflytek.sc.ssp.uc.client.context.UCCasServiceContext;
import com.iflytek.sc.ssp.uc.client.service.UCService;
import com.szah.uccp.client.demo.config.UccpAuthCodeClient;
import com.szah.uccp.client.demo.config.UccpUserInfoClient;
import com.szah.uccp.client.demo.util.sm4.SM4Utils;
import com.szah.uccp.client.demo.vo.UserUnitDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Slf4j
@Controller
public class UccpLoginController {

    @Autowired
    private UccpUserInfoClient userInfoClient;

    @Autowired
    private UccpAuthCodeClient authCodeClient;

    @Value("${uccp.restful.encrypt.switch}")
    private boolean encryptSwitch ;


    /**
     * 前后端不分离主页
     * @param session
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping(value = {"/transition"})
    public String transition(HttpSession session, Model model) throws Exception {
        UCService ucservice = UCCasServiceContext.getUcService();
        String token = ucservice.getCurrentToken(session);
        UCConstant ucConstant = UCCasServiceContext.getUcConstant();
        String appSercert = ucConstant.getAppSecret();
        String appCode = ucConstant.getAppCode();
        String authCode = getAuthCode();
        String result = userInfoClient.paramSend(appCode, appSercert, token, authCode);
        if(encryptSwitch) {
            SM4Utils sm4Utils = new SM4Utils();
            result = sm4Utils.decryptData_CBC(result, appSercert);
        }
        String userName = "未登录";
        String data = JSONObject.parseObject(result).getString("data");
        log.info("data:{}", data);
        UserUnitDto userInfo = JSONObject.parseObject(data, UserUnitDto.class);
        if("0".equals(userInfo.getAcType())){
            userName = userInfo.getPerUserVo().getName();
        }else if("1".equals(userInfo.getAcType())){
            userName = userInfo.getLegalUserVo().getOrgName();
        }
        model.addAttribute("userName",userName);
        return "index";
    }


    /**
     * 单点登出
     * @param response
     * @param session
     * @throws Exception
     */
    @GetMapping("/logout")
    @ResponseBody
    public void logout(HttpServletResponse response, HttpSession session) throws Exception {
        ServletContext context = session.getServletContext();
        UCConstant ucConstant = UCCasServiceContext.getUcConstant();
        String realPath = context.getContextPath();
        String logoutPath = ucConstant.getLogoutUrlWithAppCode()
                + "&service=" + ucConstant.getCasClientContext() + realPath + "/transition";
        if (StringUtils.isNotEmpty(logoutPath)) {
            // 手动销毁session
            session.invalidate();
            // 跳转登出统一认证中心
            response.sendRedirect(logoutPath);
        }
    }

    /**
     * 获取authCode
     * @return
     * @throws Exception
     */
    public String getAuthCode() throws Exception {
        UCConstant ucConstant = UCCasServiceContext.getUcConstant();
        String appSercert = ucConstant.getAppSecret();
        String appCode = ucConstant.getAppCode();
        String result = authCodeClient.paramSend(appCode, appSercert);
        if(encryptSwitch) {
            SM4Utils sm4Utils = new SM4Utils();
            result = sm4Utils.decryptData_CBC(result, appSercert);
        }
        String data = JSONObject.parseObject(result).getString("data");
        log.info("authCode result:{}", data);
        JSONObject obj = JSONObject.parseObject(data);

        return obj.get("authCode").toString();
    }
}

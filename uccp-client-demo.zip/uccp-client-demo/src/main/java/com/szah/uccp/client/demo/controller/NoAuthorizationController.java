package com.szah.uccp.client.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/**
 * 无需登录，可直接访问的资源
 * @Description
 * @Author weida2
 * @Date 9:16 2021/4/15
 * @Param
 * @return
 **/
@Controller
@RequestMapping("noAuthorization")
public class NoAuthorizationController {

    @GetMapping(value = {"/index", "/home"})
    public String index(HttpSession session) throws Exception {
        return "myHome";
    }
}

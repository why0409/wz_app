package com.szah.uccp.client.demo.util.sm4;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * SM4加解密工具类
 * @Description 
 * @Author jiemin2       
 * @Date 10:52 2021/8/16
 * @Param 
 * @return 
 **/
public class SM4Utils {
    public String iv = "UISwD9fW6cFh9SNS";

    public boolean hexString = false;

    private static String charSet = "UTF-8";
    public static Pattern p = Pattern.compile("\\s*|\t|\r|\n");

    public String encryptData_ECB(String plainText, String secretKey)
    {
        try
        {
            SM4_Context ctx = new SM4_Context();
            ctx.isPadding = true;
            ctx.mode = 1;
            byte[] keyBytes;
            if (this.hexString)
            {
                keyBytes = Util.hexStringToBytes(secretKey);
            }
            else
            {
                keyBytes = secretKey.getBytes();
            }

            SM4 sm4 = new SM4();
            sm4.sm4_setkey_enc(ctx, keyBytes);
            byte[] encrypted = sm4.sm4_crypt_ecb(ctx, plainText.getBytes(charSet));
            String cipherText = new BASE64Encoder().encode(encrypted);
            if ((cipherText != null) && (cipherText.trim().length() > 0))
            {
                Matcher m = p.matcher(cipherText);
                cipherText = m.replaceAll("");
            }
            return cipherText;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public String decryptData_ECB(String cipherText, String secretKey)
    {
        try
        {
            SM4_Context ctx = new SM4_Context();
            ctx.isPadding = true;
            ctx.mode = 0;
            byte[] keyBytes;
            if (this.hexString)
            {
                keyBytes = Util.hexStringToBytes(secretKey);
            }
            else
            {
                keyBytes = secretKey.getBytes();
            }

            SM4 sm4 = new SM4();
            sm4.sm4_setkey_dec(ctx, keyBytes);
            byte[] decrypted = sm4.sm4_crypt_ecb(ctx, new BASE64Decoder().decodeBuffer(cipherText));
            return new String(decrypted, charSet);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public String encryptData_CBC(String plainText, String secretKey)
    {
        try
        {
            SM4_Context ctx = new SM4_Context();
            ctx.isPadding = true;
            ctx.mode = 1;
            byte[] keyBytes;
            byte[] ivBytes;
            if (this.hexString)
            {
                keyBytes = Util.hexStringToBytes(secretKey);
                ivBytes = Util.hexStringToBytes(this.iv);
            }
            else
            {
                keyBytes = secretKey.getBytes();
                ivBytes = this.iv.getBytes();
            }

            SM4 sm4 = new SM4();
            sm4.sm4_setkey_enc(ctx, keyBytes);
            byte[] encrypted = sm4.sm4_crypt_cbc(ctx, ivBytes, plainText.getBytes(charSet));
            String cipherText = new BASE64Encoder().encode(encrypted);
            if ((cipherText != null) && (cipherText.trim().length() > 0))
            {
                Matcher m = p.matcher(cipherText);
                cipherText = m.replaceAll("");
            }
            return cipherText;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public String decryptData_CBC(String cipherText, String secretKey)
    {
        try
        {
            SM4_Context ctx = new SM4_Context();
            ctx.isPadding = true;
            ctx.mode = 0;
            byte[] keyBytes;
            byte[] ivBytes;
            if (this.hexString)
            {
                keyBytes = Util.hexStringToBytes(secretKey);
                ivBytes = Util.hexStringToBytes(this.iv);
            }
            else
            {
                keyBytes = secretKey.getBytes();
                ivBytes = this.iv.getBytes();
            }

            SM4 sm4 = new SM4();
            sm4.sm4_setkey_dec(ctx, keyBytes);
            byte[] decrypted = sm4.sm4_crypt_cbc(ctx, ivBytes, new BASE64Decoder().decodeBuffer(cipherText));
            return new String(decrypted, charSet);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    /*public static void main(String[] args) {
        String plainText = "{\"sourceAppid\":\"wx226f3d04ee35fbe1\",\"logo\":\"https://www1.hfgh.org.cn/static/img/logo.png\",\"appname\":\"测试小程序\",\"extraData\":{\"usertoken\":\"8d8881e6190640829fc7d57750c5672a\"}}";
        String appSecret = "1234567812345678";
        SM4Utils sm4 = new SM4Utils();
        sm4.hexString = false;

        System.out.println("ECB模式");
        String cipherText = sm4.encryptData_ECB(plainText, appSecret);
        System.out.println("密文: " + cipherText);
        System.out.println("");

        plainText = sm4.decryptData_ECB(cipherText, appSecret);
        System.out.println("明文: " + plainText);
        System.out.println("");

        System.out.println("CBC模式");
        sm4.iv = "UISwD9fW6cFh9SNS";
        cipherText = sm4.encryptData_CBC(plainText, appSecret);
        System.out.println("密文: " + cipherText);
        System.out.println("");

        plainText = sm4.decryptData_CBC(cipherText, appSecret);
        System.out.println("明文: " + plainText);
    }*/
}

package com.szah.uccp.client.demo.config;

import com.iflytek.sc.ssp.uc.client.context.UCCasServiceContext;
import com.szah.uccp.client.demo.util.HttpUtil;
import com.szah.uccp.client.demo.util.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * @description 获取授权码
 * @author jlye
 * @date 2024/1/24
 */
@Slf4j
@Component
public class UccpAuthCodeClient {

    @Value("${ly.service.paasId}")
    private String paasId;

    @Value("${ly.service.paasToken}")
    private String paasToken;

    @Value("${ly.service.url}")
    private String lyServiceUrl;

    @Value("${ly.restful.getAuthCode}")
    private String lyGetAuthCode;

    /**
     * 请求中转
     */
    public String paramSend(String appCode, String appSercert) throws Exception {
        String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return getAuthCode(appCode, time, appSercert, sign(appCode, appSercert, time));
    }

    /**
     *用户请求sign信息获取
     */
    public static String sign(String appCode, String appSercert, String time) {
        TreeMap<String, String> signParams = new TreeMap<String, String>();
        signParams.put("time", time);
        signParams.put("appCode", appCode);
        signParams.put("appKey", appSercert);
        String signData = SignUtil.produceData(signParams);
        return SignUtil.md5Encode(signData + appSercert);
    }

    /**
     * 调用接口信息
     * @param appCode
     * @param time
     * @param appKey
     * @param sign
     * @return
     * @throws Exception
     */
    public String getAuthCode(String appCode, String time, String appKey, String sign) throws Exception {
        String url = lyServiceUrl + lyGetAuthCode;
        // 请求体
        Map<String, Object> paramData = new HashMap<String, Object>();
        paramData.put("appKey", appKey);
        // 请求头
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("time", time);
        headers.put("appCode", appCode);
        headers.put("sign", sign);
        long now = new Date().getTime();
        String timestamp = Long.toString((long) Math.floor(now / 1000));
        String nonce = Long.toHexString(now) + "-" + Long.toHexString((long) Math.floor(Math.random() * 0xFFFFFF));
        String signature = Signature.toSHA256(timestamp + paasToken + nonce + timestamp);
        headers.put("x-tif-paasid", paasId);
        headers.put("x-tif-timestamp", timestamp);
        headers.put("x-tif-signature", signature);
        headers.put("x-tif-nonce", nonce);
        // doPost请求
        String result = HttpUtil.doPost(url, paramData, headers);
        log.info("获取authCode返回结果：{}", result);
        return result;
    }

}

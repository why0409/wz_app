package com.szah.uccp.client.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(value = "com.szah")
@SpringBootApplication
public class UccpDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(UccpDemoApplication.class, args);
    }

}

package com.szah.uccp.client.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UccpDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
